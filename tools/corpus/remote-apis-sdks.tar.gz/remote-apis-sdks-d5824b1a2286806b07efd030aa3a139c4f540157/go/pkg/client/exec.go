package client

import (
	"context"
	"errors"
	"fmt"
	"io"
	"sort"
	"time"

	"github.com/bazelbuild/remote-apis-sdks/go/pkg/digest"
	log "github.com/golang/glog"
	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
	"google.golang.org/protobuf/proto"

	// Redundant imports are required for the google3 mirror. Aliases should not be changed.
	regrpc "github.com/bazelbuild/remote-apis/build/bazel/remote/execution/v2"
	repb "github.com/bazelbuild/remote-apis/build/bazel/remote/execution/v2"
	oppb "google.golang.org/genproto/googleapis/longrunning"
	dpb "google.golang.org/protobuf/types/known/durationpb"
)

const (
	containerImagePropertyName = "container-image"
)

// Action encodes the full details of an action to be sent to the remote execution service for
// execution. It corresponds roughly, but not exactly, to the Action proto used by the Remote
// Execution API.
type Action struct {
	// Args are the command-line arguments to start the process. The first argument is the process
	// name, and the rest are its arguments.
	Args []string
	// EnvVars are the variables to add to the process's environment.
	EnvVars map[string]string
	// InputRoot and InputFiles contain the details of the input tree, in remote execution format.
	// They should normally be constructed through the PackageTree function.
	InputRoot  digest.Digest
	InputFiles map[digest.Digest][]byte
	// OutputFiles is a list of output files requested (full paths).
	OutputFiles []string
	// OutputDirs is a list of output directories requested (full paths).
	OutputDirs []string
	// Docker image is a docker:// URL to the docker image in which execution will take place.
	DockerImage string
	// Timeout is the maximum execution time for the action. Note that it's not an overall timeout on
	// the process, since there may be additional time for transferring files, waiting for a worker to
	// become available, or other overhead.
	//
	// If 0, the server's default timeout is used.
	Timeout time.Duration
	// DoNotCache, if true, indicates that the result of this action should never be cached. It
	// implies SkipCache.
	DoNotCache bool
	// SkipCache, if true, indicates that this action should be executed even if there is a copy of
	// its result in the action cache that could be used instead.
	SkipCache bool
}

// ExecuteAction performs all of the steps necessary to execute an action, including checking the
// cache if applicable, uploading necessary protos and inputs to the CAS, queueing the action, and
// waiting for the result.
//
// Execute may block for a long time while the action is in progress. Currently, two-phase
// queue-wait is not supported; the token necessary to query the job is not provided to users.
//
// This method MAY return a non-nil ActionResult along with a non-nil error if the action failed.
// The ActionResult may include, for example, the stdout/stderr digest from the attempt.
//
// ExecuteAction is a convenience method which wraps both PrepAction and ExecuteAndWait, along with
// other steps such as uploading extra inputs and parsing Operation protos.
func (c *Client) ExecuteAction(ctx context.Context, ac *Action) (*repb.ActionResult, error) {
	log.V(1).Infof("Executing action: %v", ac.Args)

	// Construct the action we're trying to run.
	acDg, res, err := c.PrepAction(ctx, ac)
	if err != nil {
		return nil, err
	}
	// If we found a result in the cache, return that.
	if res != nil {
		return res, nil
	}

	// Upload any remaining inputs.
	if err := c.WriteBlobs(ctx, ac.InputFiles); err != nil {
		return nil, fmt.Errorf("uploading input files to the CAS: %w", err)
	}

	log.V(1).Info("Executing job")
	res, err = c.executeJob(ctx, ac.SkipCache, acDg)
	if err != nil {
		return res, fmt.Errorf("executing an action: %w", err)
	}

	return res, nil
}

// CheckActionCache queries remote action cache, returning an ActionResult or nil if it doesn't exist.
func (c *Client) CheckActionCache(ctx context.Context, acDg *repb.Digest) (*repb.ActionResult, error) {
	res, err := c.GetActionResult(ctx, &repb.GetActionResultRequest{
		InstanceName: c.InstanceName,
		ActionDigest: acDg,
	})
	switch st, _ := status.FromError(err); st.Code() {
	case codes.OK:
		return res, nil
	case codes.NotFound:
		return nil, nil
	default:
		return nil, fmt.Errorf("checking the action cache: %w", err)
	}
}

func (c *Client) executeJob(ctx context.Context, skipCache bool, acDg *repb.Digest) (*repb.ActionResult, error) {
	execReq := &repb.ExecuteRequest{
		InstanceName:    c.InstanceName,
		SkipCacheLookup: skipCache,
		ActionDigest:    acDg,
	}
	op, err := c.ExecuteAndWait(ctx, execReq)
	if err != nil {
		return nil, fmt.Errorf("execution error: %w", err)
	}

	switch r := op.Result.(type) {
	case *oppb.Operation_Error:
		return nil, StatusDetailedError(status.FromProto(r.Error))
	case *oppb.Operation_Response:
		res := new(repb.ExecuteResponse)
		if err := r.Response.UnmarshalTo(res); err != nil {
			return nil, fmt.Errorf("extracting ExecuteResponse from execution operation: %w", err)
		}
		if st := status.FromProto(res.Status); st.Code() != codes.OK {
			return res.Result, fmt.Errorf("job failed with error: %w", StatusDetailedError(st))
		}
		return res.Result, nil
	default:
		return nil, errors.New("unexpected operation result type")
	}
}

// PrepAction constructs the Command and Action protos, checks the action cache if appropriate, and
// uploads the action if the cache was not checked or if there was no cache hit. If successful,
// PrepAction returns the digest of the Action and a (possibly nil) pointer to an ActionResult
// representing the result of the cache check, if any.
func (c *Client) PrepAction(ctx context.Context, ac *Action) (*repb.Digest, *repb.ActionResult, error) {
	comDg, err := c.WriteProto(ctx, buildCommand(ac))
	if err != nil {
		return nil, nil, fmt.Errorf("storing Command proto: %w", err)
	}

	reAc := &repb.Action{
		CommandDigest:   comDg.ToProto(),
		InputRootDigest: ac.InputRoot.ToProto(),
		DoNotCache:      ac.DoNotCache,
	}
	// Only set timeout if it's non-zero, because Timeout needs to be nil for the server to use a
	// default.
	if ac.Timeout != 0 {
		reAc.Timeout = dpb.New(ac.Timeout)
	}

	acBlob, err := proto.Marshal(reAc)
	if err != nil {
		return nil, nil, fmt.Errorf("marshalling Action proto: %w", err)
	}
	acDg := digest.NewFromBlob(acBlob).ToProto()

	// If the result is cacheable, check if it's already in the cache.
	if !ac.DoNotCache || !ac.SkipCache {
		log.V(1).Info("Checking cache")
		res, err := c.CheckActionCache(ctx, acDg)
		if err != nil {
			return nil, nil, err
		}
		if res != nil {
			return acDg, res, nil
		}
	}

	// No cache hit, or we didn't check. Upload the action instead.
	if _, err := c.WriteBlob(ctx, acBlob); err != nil {
		return nil, nil, fmt.Errorf("uploading action to the CAS: %w", err)
	}

	return acDg, nil, nil
}

func buildCommand(ac *Action) *repb.Command {
	cmd := &repb.Command{
		Arguments: ac.Args,
		// Do not use OutputFiles and OutputDirs directly from the Action, as we need to sort them which
		// implies modification.
		OutputFiles:       make([]string, len(ac.OutputFiles)),
		OutputDirectories: make([]string, len(ac.OutputDirs)),
		Platform: &repb.Platform{
			Properties: []*repb.Platform_Property{{Name: containerImagePropertyName, Value: ac.DockerImage}},
		},
	}
	copy(cmd.OutputFiles, ac.OutputFiles)
	copy(cmd.OutputDirectories, ac.OutputDirs)
	sort.Strings(cmd.OutputFiles)
	sort.Strings(cmd.OutputDirectories)
	for name, val := range ac.EnvVars {
		cmd.EnvironmentVariables = append(cmd.EnvironmentVariables, &repb.Command_EnvironmentVariable{Name: name, Value: val})
	}
	sort.Slice(cmd.EnvironmentVariables, func(i, j int) bool { return cmd.EnvironmentVariables[i].Name < cmd.EnvironmentVariables[j].Name })
	return cmd
}

// ExecuteAndWait calls Execute on the underlying client and WaitExecution if necessary. It returns
// the completed operation or an error.
//
// Retry model:
//   - If there's no current Operation (i.e., before the first Operation is received) or after the
//     terminal Operation (op.Done == true) has been received, the next retry calls Execute again.
//   - Otherwise, the next retry calls WaitExecution with the last known operation name.
//
// Special handling for WaitExecution NOT_FOUND (spec compliance):
//   - Per the Remote Execution API, WaitExecution may return NOT_FOUND and the client should retry by
//     calling Execute. When a NOT_FOUND is seen while invoking WaitExecution or while receiving from
//     the WaitExecution stream, this method flips back to Execute on the next retry by returning a
//     transient error to the retrier.
//   - This behavior is localized to the WaitExecution path only. The global retry policy
//     (retry.TransientOnly) remains unchanged.
//
// Status-driven retries:
//   - The retrier can also be triggered based on certain operation statuses (in addition to explicit
//     RPC errors). We surface such statuses as temporary "fake" errors inside the retry closure so the
//     retrier can decide whether to retry. Those synthetic errors are discarded at the boundary once
//     retries are exhausted or when no retrier is configured.
//   - DeadlineExceeded statuses are never handed to the retrier and are returned directly to the
//     caller.
func (c *Client) ExecuteAndWait(ctx context.Context, req *repb.ExecuteRequest) (op *oppb.Operation, err error) {
	return c.ExecuteAndWaitProgress(ctx, req, nil)
}

// ExecuteAndWaitProgress calls Execute on the underlying client and, when appropriate, switches to
// WaitExecution to follow the in-progress operation. It returns the completed operation or an error.
// The supplied callback is invoked for each streamed Operation metadata update.
//
// Behavior notes:
//   - If WaitExecution returns NOT_FOUND (either on call or mid-stream), the next retry will call
//     Execute again, per the Remote Execution API.
//   - Certain operation statuses are mapped to errors to drive retries; DeadlineExceeded statuses are
//     not given to the retrier and propagate to the caller.
func (c *Client) ExecuteAndWaitProgress(ctx context.Context, req *repb.ExecuteRequest, progress func(metadata *repb.ExecuteOperationMetadata)) (op *oppb.Operation, err error) {
	wait := false    // Should we retry by calling WaitExecution instead of Execute?
	opError := false // Are we propagating an Operation status as an error for the retrier's benefit?
	lastOp := &oppb.Operation{}
	closure := func(ctx context.Context) (e error) {
		var res regrpc.Execution_ExecuteClient
		if wait {
			res, e = c.WaitExecution(ctx, &repb.WaitExecutionRequest{Name: lastOp.Name})
		} else {
			res, e = c.Execute(ctx, req)
		}
		if e != nil {
			// Per Remote Execution API spec: handle NOT_FOUND during WaitExecution by retrying Execute.
			if wait {
				if st, ok := status.FromError(e); ok && st.Code() == codes.NotFound {
					wait = false
					return status.Errorf(codes.Unavailable, "WaitExecution returned NOT_FOUND: retrying Execute: %v", e)
				}
			}
			return e
		}
		for {
			op, e := res.Recv()
			if e == io.EOF {
				break
			}
			if e != nil {
				// Per Remote Execution API spec: handle NOT_FOUND during WaitExecution by retrying Execute.
				if wait {
					if st, ok := status.FromError(e); ok && st.Code() == codes.NotFound {
						wait = false
						return status.Errorf(codes.Unavailable, "WaitExecution stream returned NOT_FOUND: retrying Execute: %v", e)
					}
				}
				return e
			}
			wait = !op.Done
			lastOp = op
			if progress != nil {
				metadata := &repb.ExecuteOperationMetadata{}
				if err := op.Metadata.UnmarshalTo(metadata); err == nil {
					progress(metadata)
				}
			}
		}
		st := OperationStatus(lastOp)
		if st != nil {
			opError = true
			if st.Code() == codes.DeadlineExceeded {
				return nil
			}
			return st.Err()
		}
		return nil
	}
	err = c.Retrier.Do(ctx, func() error { return c.CallWithTimeout(ctx, "Execute", closure) })
	if err != nil && !opError {
		if st, ok := status.FromError(err); ok {
			err = StatusDetailedError(st)
		}
		return nil, err
	}

	// In the off chance that the server closes the stream immediately without returning any Operation
	// values and without returning an error, then lastOp will never be modified. Alternatively
	// the server could return an empty operation explicitly prior to closing the stream. Either
	// case is a server error.
	if proto.Equal(lastOp, &oppb.Operation{}) {
		return nil, errors.New("unexpected server behaviour: an empty Operation was returned, or no operation was returned")
	}

	return lastOp, nil
}

// OperationStatus returns an operation error status, if it is present, and nil otherwise.
func OperationStatus(op *oppb.Operation) *status.Status {
	var r *oppb.Operation_Response
	var ok bool
	if r, ok = op.Result.(*oppb.Operation_Response); !ok || r == nil {
		return nil
	}
	respv2 := &repb.ExecuteResponse{}
	if err := r.Response.UnmarshalTo(respv2); err != nil {
		return nil
	}
	if s, ok := status.FromError(status.FromProto(respv2.Status).Err()); ok {
		return s
	}
	return nil
}
